"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_sts_1 = require("@aws-sdk/client-sts");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const client_ec2_1 = require("@aws-sdk/client-ec2");
const uuid_1 = require("uuid");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const response_1 = require("../utils/response");
const dynamoClient = new client_dynamodb_1.DynamoDBClient({ region: process.env.REGION });
const dynamo = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
const stsClient = new client_sts_1.STSClient({ region: process.env.REGION });
const secretsManager = new client_secrets_manager_1.SecretsManagerClient({ region: process.env.REGION });
const ACCOUNTS_TABLE = process.env.ACCOUNTS_TABLE;
const ANALYSES_TABLE = process.env.ANALYSES_TABLE;
// Helper function to get JWT secret
async function getJwtSecret() {
    try {
        const result = await secretsManager.send(new client_secrets_manager_1.GetSecretValueCommand({
            SecretId: process.env.JWT_SECRET_NAME,
        }));
        const secrets = JSON.parse(result.SecretString);
        return secrets.jwtSecret;
    }
    catch (error) {
        console.error('Error fetching JWT secret:', error);
        throw new Error('Failed to fetch JWT secret');
    }
}
// Helper function to authenticate user from JWT token
async function authenticateUser(event) {
    try {
        const authHeader = event.headers?.Authorization || event.headers?.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return null;
        }
        const token = authHeader.replace('Bearer ', '');
        const secret = await getJwtSecret();
        const decoded = jsonwebtoken_1.default.verify(token, secret);
        if (!decoded.userId || !decoded.email) {
            return null;
        }
        return {
            userId: decoded.userId,
            email: decoded.email,
            subscriptionTier: decoded.subscriptionTier || 'starter'
        };
    }
    catch (error) {
        console.error('Authentication error:', error);
        return null;
    }
}
const handler = async (event, context) => {
    try {
        // Authenticate user
        const user = await authenticateUser(event);
        if (!user) {
            return (0, response_1.createErrorResponse)(401, 'Unauthorized');
        }
        const { accountId } = JSON.parse(event.body || '{}');
        if (!accountId) {
            return (0, response_1.createErrorResponse)(400, 'accountId is required');
        }
        // 1. Get account details from DynamoDB
        const accountResult = await dynamo.send(new lib_dynamodb_1.GetCommand({
            TableName: ACCOUNTS_TABLE,
            Key: { accountId },
        }));
        if (!accountResult.Item || accountResult.Item.userId !== user.userId) {
            return (0, response_1.createErrorResponse)(404, 'Account not found or access denied');
        }
        const account = accountResult.Item;
        // 2. Assume the cross-account role
        const assumeRoleCommand = new client_sts_1.AssumeRoleCommand({
            RoleArn: account.roleArn,
            RoleSessionName: `CostOptimizerAnalysis-${Date.now()}`,
            ExternalId: account.externalId || `cost-saver-${account.awsAccountId}`,
        });
        const credentials = await stsClient.send(assumeRoleCommand);
        const ec2Client = new client_ec2_1.EC2Client({
            region: account.region,
            credentials: {
                accessKeyId: credentials.Credentials.AccessKeyId,
                secretAccessKey: credentials.Credentials.SecretAccessKey,
                sessionToken: credentials.Credentials.SessionToken,
            },
        });
        // 3. Perform the analysis
        const analysisId = (0, uuid_1.v4)();
        const analysisStartTime = new Date().toISOString();
        // Create an initial analysis record
        await dynamo.send(new lib_dynamodb_1.PutCommand({
            TableName: ANALYSES_TABLE,
            Item: {
                analysisId,
                userId: user.userId,
                accountId,
                status: 'in-progress',
                createdAt: analysisStartTime,
                updatedAt: analysisStartTime,
            },
        }));
        // Example: Find unattached EBS volumes
        const { Volumes } = await ec2Client.send(new client_ec2_1.DescribeVolumesCommand({}));
        const unattachedVolumes = Volumes
            ?.filter(v => v.State === 'available')
            .map(v => ({
            volumeId: v.VolumeId,
            size: v.Size,
            region: account.region,
            potentialSavings: (v.Size || 0) * 0.1, // Approximate cost per GB
        })) || [];
        // 4. Store the results in DynamoDB
        const analysisResult = {
            unattachedVolumes,
        };
        const analysisFinishTime = new Date().toISOString();
        await dynamo.send(new lib_dynamodb_1.UpdateCommand({
            TableName: ANALYSES_TABLE,
            Key: { analysisId },
            UpdateExpression: 'set #status = :status, #result = :result, #updatedAt = :updatedAt',
            ExpressionAttributeNames: {
                '#status': 'status',
                '#result': 'result',
                '#updatedAt': 'updatedAt',
            },
            ExpressionAttributeValues: {
                ':status': 'completed',
                ':result': analysisResult,
                ':updatedAt': analysisFinishTime,
            },
        }));
        return (0, response_1.createSuccessResponse)({
            message: 'Analysis completed successfully',
            analysisId,
            result: analysisResult,
        });
    }
    catch (error) {
        console.error('Analysis error:', error);
        return (0, response_1.createErrorResponse)(500, 'Internal server error');
    }
};
exports.handler = handler;
//# sourceMappingURL=analysis.js.map