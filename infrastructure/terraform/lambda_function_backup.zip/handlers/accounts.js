"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.remove = exports.add = exports.list = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_sts_1 = require("@aws-sdk/client-sts");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const uuid_1 = require("uuid");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const response_1 = require("../utils/response");
const dynamoClient = new client_dynamodb_1.DynamoDBClient({ region: process.env.REGION });
const dynamo = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
const stsClient = new client_sts_1.STSClient({ region: process.env.REGION });
const secretsManager = new client_secrets_manager_1.SecretsManagerClient({ region: process.env.REGION });
const ACCOUNTS_TABLE = process.env.ACCOUNTS_TABLE;
const USERS_TABLE = process.env.USERS_TABLE;
// Helper function to get JWT secret
async function getJwtSecret() {
    try {
        const result = await secretsManager.send(new client_secrets_manager_1.GetSecretValueCommand({
            SecretId: process.env.JWT_SECRET_NAME,
        }));
        const secrets = JSON.parse(result.SecretString);
        return secrets.jwtSecret;
    }
    catch (error) {
        console.error('Error fetching JWT secret:', error);
        throw new Error('Failed to fetch JWT secret');
    }
}
// Helper function to authenticate user from JWT token
async function authenticateUser(event) {
    try {
        const authHeader = event.headers?.Authorization || event.headers?.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return null;
        }
        const token = authHeader.replace('Bearer ', '');
        const secret = await getJwtSecret();
        const decoded = jsonwebtoken_1.default.verify(token, secret);
        if (!decoded.userId || !decoded.email) {
            return null;
        }
        return {
            userId: decoded.userId,
            email: decoded.email,
            subscriptionTier: decoded.subscriptionTier || 'starter'
        };
    }
    catch (error) {
        console.error('Authentication error:', error);
        return null;
    }
}
const list = async (event, context) => {
    try {
        const method = event.requestContext?.http?.method || event.httpMethod;
        if (method === 'OPTIONS') {
            return (0, response_1.handleCorsPreflightRequest)();
        }
        // Authenticate user
        const user = await authenticateUser(event);
        if (!user) {
            return (0, response_1.createErrorResponse)(401, 'Unauthorized');
        }
        // Get user's AWS accounts
        const result = await dynamo.send(new lib_dynamodb_1.QueryCommand({
            TableName: ACCOUNTS_TABLE,
            IndexName: 'UserIndex',
            KeyConditionExpression: 'userId = :userId',
            ExpressionAttributeValues: {
                ':userId': user.userId,
            },
        }));
        const accounts = (result.Items || []).map(item => ({
            id: item.accountId,
            accountId: item.awsAccountId,
            accountName: item.accountName,
            region: item.region,
            roleArn: item.roleArn,
            status: item.status,
            lastAnalyzed: item.lastAnalyzed,
            createdAt: item.createdAt,
            updatedAt: item.updatedAt,
        }));
        return (0, response_1.createSuccessResponse)({ accounts });
    }
    catch (error) {
        console.error('List accounts error:', error);
        return (0, response_1.createErrorResponse)(500, 'Internal server error');
    }
};
exports.list = list;
const add = async (event, context) => {
    try {
        const method = event.requestContext?.http?.method || event.httpMethod;
        if (method === 'OPTIONS') {
            return (0, response_1.handleCorsPreflightRequest)();
        }
        // Authenticate user
        const user = await authenticateUser(event);
        if (!user) {
            return (0, response_1.createErrorResponse)(401, 'Unauthorized');
        }
        const { accountName, accountId, region, roleArn, externalId, isOrganization } = JSON.parse(event.body || '{}');
        // For organizations, extract account ID from role ARN
        let effectiveAccountId = accountId;
        if (isOrganization && !accountId) {
            const arnMatch = roleArn.match(/arn:aws:iam::(\d{12}):role\//);
            if (arnMatch) {
                effectiveAccountId = arnMatch[1];
            }
        }
        // Validate input
        if (!accountName || !effectiveAccountId || !region || !roleArn) {
            return (0, response_1.createErrorResponse)(400, 'Account name, AWS account ID, region, and role ARN are required');
        }
        if (!(0, response_1.validateAwsAccountId)(effectiveAccountId)) {
            return (0, response_1.createErrorResponse)(400, 'AWS Account ID must be exactly 12 digits (e.g., 123456789012)');
        }
        if (!(0, response_1.validateAwsRegion)(region)) {
            return (0, response_1.createErrorResponse)(400, 'Please select a valid AWS region from the dropdown');
        }
        if (!(0, response_1.validateRoleArn)(roleArn)) {
            return (0, response_1.createErrorResponse)(400, 'Role ARN must be in format: arn:aws:iam::123456789012:role/RoleName');
        }
        // Check user's account limit
        const userResult = await dynamo.send(new lib_dynamodb_1.GetCommand({
            TableName: USERS_TABLE,
            Key: { userId: user.userId },
        }));
        if (!userResult.Item) {
            return (0, response_1.createErrorResponse)(404, 'User not found');
        }
        const userRecord = userResult.Item;
        const accountsLimit = userRecord?.accountsLimit || 3;
        // Count existing accounts
        const existingAccounts = await dynamo.send(new lib_dynamodb_1.QueryCommand({
            TableName: ACCOUNTS_TABLE,
            IndexName: 'UserIndex',
            KeyConditionExpression: 'userId = :userId',
            ExpressionAttributeValues: {
                ':userId': user.userId,
            },
            Select: 'COUNT',
        }));
        const accountCount = existingAccounts.Count || 0;
        if (accountCount >= accountsLimit) {
            return (0, response_1.createErrorResponse)(403, `Account limit reached. Your ${userRecord?.subscriptionTier || user.subscriptionTier || 'current'} plan allows ${accountsLimit} accounts. Upgrade your plan to add more accounts.`);
        }
        // Test AWS credentials by assuming the role
        try {
            const effectiveExternalId = externalId || `cost-saver-${effectiveAccountId}`;
            console.log('Attempting to assume role:', {
                roleArn,
                externalId: effectiveExternalId,
                accountId: effectiveAccountId,
                isOrganization
            });
            const assumeRoleCommand = new client_sts_1.AssumeRoleCommand({
                RoleArn: roleArn,
                RoleSessionName: `CostOptimizerValidation-${Date.now()}`,
                ExternalId: effectiveExternalId,
                DurationSeconds: 900, // 15 minutes
            });
            const credentials = await stsClient.send(assumeRoleCommand);
            // Verify we can use the assumed role
            const tempStsClient = new client_sts_1.STSClient({
                region: region,
                credentials: {
                    accessKeyId: credentials.Credentials.AccessKeyId,
                    secretAccessKey: credentials.Credentials.SecretAccessKey,
                    sessionToken: credentials.Credentials.SessionToken,
                },
            });
            const identity = await tempStsClient.send(new client_sts_1.GetCallerIdentityCommand({}));
            if (identity.Account !== effectiveAccountId) {
                return (0, response_1.createErrorResponse)(400, 'Role ARN does not belong to the specified AWS account. Please verify both the Role ARN and AWS Account ID are correct.');
            }
        }
        catch (error) {
            console.error('Role assumption failed:', error);
            if (error.name === 'AccessDenied') {
                return (0, response_1.createErrorResponse)(400, 'Access denied when assuming role. Please ensure:\n1. The IAM role exists and is named correctly\n2. The role trusts account 504264909935 (Cost Saver)\n3. The role has the required permissions (ReadOnlyAccess + Billing)');
            }
            if (error.name === 'InvalidParameterValue') {
                return (0, response_1.createErrorResponse)(400, 'Invalid Role ARN format. Please check the role ARN is correct.');
            }
            if (error.name === 'NoSuchEntity') {
                return (0, response_1.createErrorResponse)(400, 'Role not found. Please verify the role exists and the ARN is correct.');
            }
            return (0, response_1.createErrorResponse)(400, `Failed to connect to AWS account: ${error.message || 'Unknown error'}. Please check your IAM role setup.`);
        }
        // Create account record
        const accountRecordId = (0, uuid_1.v4)();
        const now = new Date().toISOString();
        const accountRecord = {
            accountId: accountRecordId,
            userId: user.userId,
            accountName: (0, response_1.sanitizeInput)(accountName, 100),
            awsAccountId: effectiveAccountId,
            region,
            roleArn,
            externalId: externalId || undefined,
            status: 'active',
            createdAt: now,
            updatedAt: now,
            isOrganization: isOrganization || undefined,
        };
        // Save account to database
        await dynamo.send(new lib_dynamodb_1.PutCommand({
            TableName: ACCOUNTS_TABLE,
            Item: accountRecord,
        }));
        // Return account data
        const accountResponse = {
            id: accountRecord.accountId,
            accountId: accountRecord.awsAccountId,
            accountName: accountRecord.accountName,
            region: accountRecord.region,
            roleArn: accountRecord.roleArn,
            status: accountRecord.status,
            createdAt: accountRecord.createdAt,
            updatedAt: accountRecord.updatedAt,
        };
        return (0, response_1.createSuccessResponse)({ account: accountResponse }, 201);
    }
    catch (error) {
        console.error('Add account error:', error);
        return (0, response_1.createErrorResponse)(500, 'Internal server error');
    }
};
exports.add = add;
const remove = async (event, context) => {
    try {
        const method = event.requestContext?.http?.method || event.httpMethod;
        if (method === 'OPTIONS') {
            return (0, response_1.handleCorsPreflightRequest)();
        }
        // Authenticate user
        const user = await authenticateUser(event);
        if (!user) {
            return (0, response_1.createErrorResponse)(401, 'Unauthorized');
        }
        const { accountId } = (0, response_1.parsePathParameters)(event);
        if (!accountId) {
            return (0, response_1.createErrorResponse)(400, 'Account ID is required');
        }
        // Get account to verify ownership
        const accountResult = await dynamo.send(new lib_dynamodb_1.GetCommand({
            TableName: ACCOUNTS_TABLE,
            Key: { accountId },
        }));
        if (!accountResult.Item) {
            return (0, response_1.createErrorResponse)(404, 'Account not found');
        }
        const account = accountResult.Item;
        if (account.userId !== user.userId) {
            return (0, response_1.createErrorResponse)(403, 'Access denied');
        }
        // Delete account
        await dynamo.send(new lib_dynamodb_1.DeleteCommand({
            TableName: ACCOUNTS_TABLE,
            Key: { accountId },
        }));
        return (0, response_1.createSuccessResponse)({ message: 'Account removed successfully' });
    }
    catch (error) {
        console.error('Remove account error:', error);
        return (0, response_1.createErrorResponse)(500, 'Internal server error');
    }
};
exports.remove = remove;
// Main handler function that routes based on HTTP method
const handler = async (event, context) => {
    try {
        // API Gateway v2 (HTTP API) uses different event structure than v1 (REST API)
        const method = event.requestContext?.http?.method || event.httpMethod;
        switch (method) {
            case 'OPTIONS':
                return (0, response_1.handleCorsPreflightRequest)();
            case 'GET':
                return (0, exports.list)(event, context);
            case 'POST':
                return (0, exports.add)(event, context);
            case 'DELETE':
                return (0, exports.remove)(event, context);
            default:
                return (0, response_1.createErrorResponse)(405, 'Method not allowed');
        }
    }
    catch (error) {
        console.error('Handler error:', error);
        return (0, response_1.createErrorResponse)(500, 'Internal server error');
    }
};
exports.handler = handler;
//# sourceMappingURL=accounts.js.map