"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const response_1 = require("../utils/response");
const stripe_1 = __importDefault(require("stripe"));
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const secretsManagerClient = new client_secrets_manager_1.SecretsManagerClient({ region: process.env.REGION });
const APP_SECRETS_ARN = process.env.APP_SECRETS_ARN;
let stripeSecretKey;
let stripeWebhookSecret;
async function getStripeSecrets() {
    if (stripeSecretKey && stripeWebhookSecret) {
        return { stripeSecretKey, stripeWebhookSecret };
    }
    try {
        const command = new client_secrets_manager_1.GetSecretValueCommand({ SecretId: APP_SECRETS_ARN });
        const data = await secretsManagerClient.send(command);
        if (data.SecretString) {
            const secrets = JSON.parse(data.SecretString);
            stripeSecretKey = secrets.stripeSecretKey;
            stripeWebhookSecret = secrets.stripeWebhookSecret;
            return { stripeSecretKey, stripeWebhookSecret };
        }
        throw new Error('Stripe secrets not found in Secrets Manager');
    }
    catch (error) {
        console.error('Error retrieving Stripe secrets from Secrets Manager:', error);
        throw new Error('Could not retrieve Stripe secrets');
    }
}
const handler = async (event, context) => {
    try {
        const { stripeSecretKey, stripeWebhookSecret } = await getStripeSecrets();
        if (!stripeSecretKey || !stripeWebhookSecret) {
            return (0, response_1.createErrorResponse)(500, 'Stripe configuration not available');
        }
        const stripe = new stripe_1.default(stripeSecretKey, { apiVersion: '2024-04-10' });
        const sig = event.headers['stripe-signature'];
        let stripeEvent;
        try {
            stripeEvent = stripe.webhooks.constructEvent(event.body, sig, stripeWebhookSecret);
        }
        catch (err) {
            console.error('Stripe webhook signature verification failed:', err);
            return (0, response_1.createErrorResponse)(400, `Webhook Error: ${err.message}`);
        }
        // Handle the event
        switch (stripeEvent.type) {
            case 'checkout.session.completed':
                const session = stripeEvent.data.object;
                // TODO: Fulfill the purchase...
                console.log('Checkout session completed:', session);
                break;
            // ... handle other event types
            default:
                console.log(`Unhandled event type ${stripeEvent.type}`);
        }
        return (0, response_1.createSuccessResponse)({ received: true });
    }
    catch (error) {
        console.error('Stripe webhook error:', error);
        return (0, response_1.createErrorResponse)(500, 'Internal server error');
    }
};
exports.handler = handler;
//# sourceMappingURL=stripe.js.map