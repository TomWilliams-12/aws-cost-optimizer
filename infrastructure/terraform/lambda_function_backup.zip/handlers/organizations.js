"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.getOrganizationStatus = exports.deployStackSet = exports.detectOrganization = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_organizations_1 = require("@aws-sdk/client-organizations");
const client_cloudformation_1 = require("@aws-sdk/client-cloudformation");
const client_sts_1 = require("@aws-sdk/client-sts");
const uuid_1 = require("uuid");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const dynamoClient = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION });
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
const organizationsClient = new client_organizations_1.OrganizationsClient({ region: process.env.AWS_REGION });
const cloudFormationClient = new client_cloudformation_1.CloudFormationClient({ region: process.env.AWS_REGION });
const secretsClient = new client_secrets_manager_1.SecretsManagerClient({ region: process.env.AWS_REGION });
const ORGANIZATIONS_TABLE = process.env.ORGANIZATIONS_TABLE || 'aws-cost-optimizer-organizations';
const ORG_ACCOUNTS_TABLE = process.env.ORG_ACCOUNTS_TABLE || 'aws-cost-optimizer-org-accounts';
// Get JWT secret from Secrets Manager
async function getJwtSecret() {
    const command = new client_secrets_manager_1.GetSecretValueCommand({
        SecretId: process.env.JWT_SECRET_NAME || 'aws-cost-optimizer-jwt-secret'
    });
    const secret = await secretsClient.send(command);
    return secret.SecretString || '';
}
// Verify JWT token
async function verifyToken(authHeader) {
    if (!authHeader?.startsWith('Bearer ')) {
        throw new Error('Invalid authorization header');
    }
    const token = authHeader.slice(7);
    const jwtSecret = await getJwtSecret();
    return jsonwebtoken_1.default.verify(token, jwtSecret);
}
// Calculate pricing tier based on account count
function calculatePricingTier(accountCount) {
    if (accountCount <= 3) {
        return { tier: 'Starter', monthlyCost: 49 };
    }
    else if (accountCount <= 10) {
        return { tier: 'Professional', monthlyCost: 149 };
    }
    else {
        return { tier: 'Enterprise', monthlyCost: 0 }; // Custom pricing
    }
}
// Detect AWS Organization
async function detectOrganization(event) {
    console.log('Organization detection request:', JSON.stringify(event, null, 2));
    try {
        // Verify authentication
        const user = await verifyToken(event.headers.Authorization || '');
        // Parse request body
        const body = JSON.parse(event.body || '{}');
        const { region = 'us-east-1', roleArn } = body;
        let orgsClient = organizationsClient;
        // If roleArn is provided, assume role first
        if (roleArn) {
            const stsClient = new client_sts_1.STSClient({ region });
            const assumeRoleCommand = new client_sts_1.AssumeRoleCommand({
                RoleArn: roleArn,
                RoleSessionName: 'aws-cost-optimizer-org-detection',
                ExternalId: body.externalId
            });
            const assumeRoleResult = await stsClient.send(assumeRoleCommand);
            const credentials = assumeRoleResult.Credentials;
            orgsClient = new client_organizations_1.OrganizationsClient({
                region,
                credentials: {
                    accessKeyId: credentials?.AccessKeyId || '',
                    secretAccessKey: credentials?.SecretAccessKey || '',
                    sessionToken: credentials?.SessionToken
                }
            });
        }
        // Check if caller is in management account
        const orgCommand = new client_organizations_1.DescribeOrganizationCommand({});
        const orgResult = await orgsClient.send(orgCommand);
        if (!orgResult.Organization) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    error: 'No AWS Organization found. This API must be called from the management account.'
                })
            };
        }
        const organizationId = orgResult.Organization.Id;
        const managementAccountId = orgResult.Organization.MasterAccountId;
        // Get organization root
        const rootsCommand = new client_organizations_1.ListRootsCommand({});
        const rootsResult = await orgsClient.send(rootsCommand);
        const rootId = rootsResult.Roots?.[0]?.Id;
        if (!rootId) {
            throw new Error('Could not find organization root');
        }
        // Get all organizational units
        const ouCommand = new client_organizations_1.ListOrganizationalUnitsForParentCommand({
            ParentId: rootId
        });
        const ouResult = await orgsClient.send(ouCommand);
        // Get accounts for each OU (and root)
        const organizationalUnits = [];
        // Add root level accounts
        const rootAccountsCommand = new client_organizations_1.ListAccountsCommand({});
        const rootAccountsResult = await orgsClient.send(rootAccountsCommand);
        const allAccounts = rootAccountsResult.Accounts || [];
        // Process OUs
        for (const ou of ouResult.OrganizationalUnits || []) {
            const ouAccountsCommand = new client_organizations_1.ListAccountsCommand({});
            const ouAccountsResult = await orgsClient.send(ouAccountsCommand);
            // Filter accounts that belong to this OU (this is simplified - in reality you'd need to traverse the tree)
            const ouAccounts = allAccounts
                .filter(account => account.Status === 'ACTIVE')
                .map(account => ({
                id: account.Id,
                name: account.Name,
                email: account.Email,
                status: account.Status
            }));
            organizationalUnits.push({
                id: ou.Id,
                name: ou.Name,
                parentId: rootId,
                accounts: ouAccounts
            });
        }
        // Calculate pricing
        const totalAccounts = allAccounts.filter(acc => acc.Status === 'ACTIVE').length;
        const { tier, monthlyCost } = calculatePricingTier(totalAccounts);
        const organizationInfo = {
            organizationId,
            managementAccountId,
            organizationalUnits,
            totalAccounts,
            pricingTier: tier,
            monthlyCost
        };
        console.log('Organization detected successfully:', organizationInfo);
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify(organizationInfo)
        };
    }
    catch (error) {
        console.error('Organization detection error:', error);
        if (error instanceof Error) {
            if (error.name === 'AWSOrganizationsNotInUseException') {
                return {
                    statusCode: 400,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        error: 'AWS Organizations is not enabled for this account.',
                        suggestion: 'Enable AWS Organizations in the AWS console first.'
                    })
                };
            }
            if (error.name === 'AccessDeniedException') {
                return {
                    statusCode: 403,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        error: 'Insufficient permissions to access AWS Organizations.',
                        suggestion: 'Ensure you are calling from the management account with proper IAM permissions.'
                    })
                };
            }
        }
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                error: 'Failed to detect organization',
                details: error instanceof Error ? error.message : 'Unknown error'
            })
        };
    }
}
exports.detectOrganization = detectOrganization;
// Deploy StackSet to organization
async function deployStackSet(event) {
    console.log('StackSet deployment request:', JSON.stringify(event, null, 2));
    try {
        // Verify authentication
        const user = await verifyToken(event.headers.Authorization || '');
        // Parse request body
        const body = JSON.parse(event.body || '{}');
        const { organizationId, targetOUs, excludeAccounts = [], region = 'us-east-1', roleArn } = body;
        // Generate external ID for the organization
        const externalId = `org-${organizationId}-${Date.now()}`;
        const stackSetName = `aws-cost-optimizer-org-${organizationId}`;
        // CloudFormation template for organization role
        const template = JSON.stringify({
            AWSTemplateFormatVersion: '2010-09-09',
            Description: 'AWS Cost Optimizer Organization Role - Read-only access for cost analysis',
            Parameters: {
                ExternalId: {
                    Type: 'String',
                    Description: 'External ID for cross-account role access',
                    Default: externalId
                },
                TrustedAccountId: {
                    Type: 'String',
                    Description: 'AWS Account ID that can assume this role',
                    Default: process.env.TRUSTED_ACCOUNT_ID || '123456789012'
                }
            },
            Resources: {
                AWSCostOptimizerRole: {
                    Type: 'AWS::IAM::Role',
                    Properties: {
                        RoleName: 'AWSCostOptimizerOrganizationRole',
                        AssumeRolePolicyDocument: {
                            Version: '2012-10-17',
                            Statement: [{
                                    Effect: 'Allow',
                                    Principal: {
                                        AWS: { Ref: 'TrustedAccountId' }
                                    },
                                    Action: 'sts:AssumeRole',
                                    Condition: {
                                        StringEquals: {
                                            'sts:ExternalId': { Ref: 'ExternalId' }
                                        }
                                    }
                                }]
                        },
                        ManagedPolicyArns: [
                            'arn:aws:iam::aws:policy/ReadOnlyAccess'
                        ],
                        Tags: [
                            {
                                Key: 'Purpose',
                                Value: 'AWS Cost Optimizer Organization Access'
                            },
                            {
                                Key: 'ExternalId',
                                Value: { Ref: 'ExternalId' }
                            }
                        ]
                    }
                }
            },
            Outputs: {
                RoleArn: {
                    Description: 'ARN of the created IAM role',
                    Value: { 'Fn::GetAtt': ['AWSCostOptimizerRole', 'Arn'] }
                },
                ExternalId: {
                    Description: 'External ID for assuming the role',
                    Value: { Ref: 'ExternalId' }
                }
            }
        });
        // Create StackSet
        const createStackSetCommand = new client_cloudformation_1.CreateStackSetCommand({
            StackSetName: stackSetName,
            TemplateBody: template,
            Capabilities: ['CAPABILITY_NAMED_IAM'],
            Description: 'AWS Cost Optimizer organization-wide IAM roles for cost analysis',
            Parameters: [
                {
                    ParameterKey: 'ExternalId',
                    ParameterValue: externalId
                },
                {
                    ParameterKey: 'TrustedAccountId',
                    ParameterValue: process.env.TRUSTED_ACCOUNT_ID || '123456789012'
                }
            ],
            PermissionModel: 'SERVICE_MANAGED',
            AutoDeployment: {
                Enabled: true,
                RetainStacksOnAccountRemoval: false
            }
        });
        const stackSetResult = await cloudFormationClient.send(createStackSetCommand);
        console.log('StackSet created:', stackSetResult.StackSetId);
        // Create stack instances for target OUs
        const createInstancesCommand = new client_cloudformation_1.CreateStackInstancesCommand({
            StackSetName: stackSetName,
            DeploymentTargets: {
                OrganizationalUnitIds: targetOUs,
                AccountFilterType: excludeAccounts.length > 0 ? 'DIFFERENCE' : 'NONE',
                Accounts: excludeAccounts.length > 0 ? excludeAccounts : undefined
            },
            Regions: [region],
            OperationId: (0, uuid_1.v4)()
        });
        const instancesResult = await cloudFormationClient.send(createInstancesCommand);
        console.log('Stack instances creation initiated:', instancesResult.OperationId);
        // Store organization info in DynamoDB
        const organizationRecord = {
            id: (0, uuid_1.v4)(),
            organizationId,
            externalId,
            stackSetId: stackSetResult.StackSetId,
            stackSetName,
            targetOUs,
            excludeAccounts,
            region,
            userId: user.sub,
            deploymentStatus: 'DEPLOYING',
            operationId: instancesResult.OperationId,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: ORGANIZATIONS_TABLE,
            Item: organizationRecord
        }));
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                success: true,
                stackSetId: stackSetResult.StackSetId,
                operationId: instancesResult.OperationId,
                externalId,
                deploymentStatus: 'DEPLOYING',
                message: 'StackSet deployment initiated. Roles will be created across all specified accounts.'
            })
        };
    }
    catch (error) {
        console.error('StackSet deployment error:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                error: 'Failed to deploy StackSet',
                details: error instanceof Error ? error.message : 'Unknown error'
            })
        };
    }
}
exports.deployStackSet = deployStackSet;
// Get organization deployment status
async function getOrganizationStatus(event) {
    try {
        // Verify authentication
        const user = await verifyToken(event.headers.Authorization || '');
        const organizationId = event.pathParameters?.organizationId;
        if (!organizationId) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ error: 'Organization ID is required' })
            };
        }
        // Get organization record
        const queryCommand = new lib_dynamodb_1.QueryCommand({
            TableName: ORGANIZATIONS_TABLE,
            IndexName: 'organizationId-index',
            KeyConditionExpression: 'organizationId = :orgId',
            ExpressionAttributeValues: {
                ':orgId': organizationId
            }
        });
        const result = await docClient.send(queryCommand);
        const organization = result.Items?.[0];
        if (!organization) {
            return {
                statusCode: 404,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ error: 'Organization not found' })
            };
        }
        // Check StackSet deployment status
        const describeStackSetCommand = new client_cloudformation_1.DescribeStackSetCommand({
            StackSetName: organization.stackSetName
        });
        const stackSetInfo = await cloudFormationClient.send(describeStackSetCommand);
        // Get stack instances status
        const listInstancesCommand = new client_cloudformation_1.ListStackInstancesCommand({
            StackSetName: organization.stackSetName
        });
        const instancesInfo = await cloudFormationClient.send(listInstancesCommand);
        const deploymentSummary = {
            organizationId,
            deploymentStatus: organization.deploymentStatus,
            stackSetStatus: stackSetInfo.StackSet?.Status,
            totalTargetAccounts: instancesInfo.Summaries?.length || 0,
            successfulDeployments: instancesInfo.Summaries?.filter(s => s.Status === client_cloudformation_1.StackInstanceStatus.CURRENT).length || 0,
            failedDeployments: instancesInfo.Summaries?.filter(s => s.Status === client_cloudformation_1.StackInstanceStatus.INOPERABLE).length || 0,
            inProgressDeployments: instancesInfo.Summaries?.filter(s => s.Status === client_cloudformation_1.StackInstanceStatus.OUTDATED).length || 0,
            accounts: instancesInfo.Summaries?.map(summary => ({
                accountId: summary.Account,
                region: summary.Region,
                status: summary.Status,
                statusReason: summary.StatusReason
            })) || []
        };
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify(deploymentSummary)
        };
    }
    catch (error) {
        console.error('Get organization status error:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                error: 'Failed to get organization status',
                details: error instanceof Error ? error.message : 'Unknown error'
            })
        };
    }
}
exports.getOrganizationStatus = getOrganizationStatus;
// Lambda handler routing
async function handler(event) {
    console.log('Organizations handler received event:', JSON.stringify(event, null, 2));
    const { httpMethod, pathParameters } = event;
    const path = event.requestContext?.routeKey || '';
    try {
        if (path === 'POST /organizations/detect') {
            return await detectOrganization(event);
        }
        if (path === 'POST /organizations/deploy') {
            return await deployStackSet(event);
        }
        if (path === 'GET /organizations/{organizationId}/status') {
            return await getOrganizationStatus(event);
        }
        return {
            statusCode: 404,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error: 'Route not found' })
        };
    }
    catch (error) {
        console.error('Handler error:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                error: 'Internal server error',
                details: error instanceof Error ? error.message : 'Unknown error'
            })
        };
    }
}
exports.handler = handler;
//# sourceMappingURL=organizations.js.map